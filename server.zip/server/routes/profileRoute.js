const router = require("express").Router();
const profile = require("../controllers/profile/ProfileControllers")

        
const multer = require('multer');
// const { validate } = require("../validation/validateModel");

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    },
});

const upload = multer({ storage });

router.post("/createProfile",upload.single('image'), profile.createProfile)
router.get("/getProfile/:ownerId" , profile.getProfile)
router.delete("/deleteProfile/:profileId", profile.deleteProfile)


module.exports = router