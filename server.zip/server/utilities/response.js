exports.successAction = (data, message = 'OK') => {


    // console.log("data",data)
    const data1 = { statusCode: 200, data, message }
    return data1

}
 
exports.failAction = (message = 'Fail', statusCode = 400, data = null) => {
    const data1 = { statusCode, data, message }
    return data1

}