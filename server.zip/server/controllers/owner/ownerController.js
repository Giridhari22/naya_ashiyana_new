const Owner = require("../../models/ownersModel")
const bcrypt = require('bcrypt');
const jwt = require("jsonwebtoken")
const mongoose = require("mongoose")
const nodemailer = require("nodemailer");
const { successAction, failAction } = require("../../utilities/response")
const ownerService = require("../../services/owner/ownerService")
const message = require("../../utilities/messages");
const { transporter, generateOTP } = require("../../utilities/customFunction")

exports.SignupOwner = async (req, res) => {
  try {
    const creatingOwner = await ownerService.SignupOwnerServices(req)
    res.status(200).json(successAction(creatingOwner, 'owner created successfully'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}



exports.sendOtp = async (req, res) => {
  try {
    const sendingOtpOwner = await ownerService.SignupOwnerServices(req)
    res.status(200).json(successAction(sendingOtpOwner, 'otp sent successfully'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
};



exports.Login = async (req, res) => {
  try {
    const LoginOwner = await ownerService.LoginServices(req)
    res.status(200).json(successAction(LoginOwner, 'owner logged in successfully'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}

exports.getOwner = async (req, res) => {
  try {
    const gettingOwner = await ownerService.getOwnerServices(req)
    res.status(200).json(successAction(gettingOwner, 'owner found successfully'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}

// Update a owner
exports.updateOwner = async (req, res) => {
  try {
    const updatingOwner = await ownerService.updateOwnerServices(req)
    res.status(200).json(successAction(updatingOwner, 'owner updated successfully'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}



// Delete a owner
exports.deleteOwner = async (req, res) => {
  try {
    const deletingOwner = await ownerService.deleteOwnerService(req)
    res.status(200).json(successAction(deletingOwner, 'owner deleted successfully'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}