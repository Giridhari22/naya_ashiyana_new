const User = require("../../models/userModels")
const userServices = require("../../services/user/userService")
const bcrypt = require('bcrypt');
const jwt = require("jsonwebtoken")
const mongoose = require("mongoose")
const nodemailer = require("nodemailer");
const message = require("../../utilities/messages");
const { successAction, failAction } = require("../../utilities/response");

exports.SignupUser = async (req, res, next) => {
  try {
    const signUp = await userServices.SignupUserfn(req)
    res.status(200).json(successAction(signUp, 'user created'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}




exports.sendOtp = async (req, res, next) => {
  try {

    const otpSending = await userServices.sendOtpfn(req)
    res.status(200).json(successAction(otpSending, 'otp sent sucessfully'))

  } catch (error) {
    res.status(400).json(failAction(error.message, 400))

  }
}



exports.Login = async (req, res) => {
  try {
    const loggedIn = await userServices.Loginfn(req)
    res.status(200).json(successAction(loggedIn, 'LoggedIn sucessfully'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}


exports.resendOtp = async (req, res) => {
  try {
    const otpResend = await userServices.resendOtpfn(req)
    res.status(200).json(successAction(otpResend, 'otp resending sucessfully'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}

exports.getUser = async (req, res) => {
  try {
    const gettingUser = await userServices.getUserfn(req)
    res.status(200).json(successAction(gettingUser, 'user get sucessfully'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}


// Update a user
exports.updateUser = async (req, res) => {
  try {
    const updatingUser = await userServices.updateUserfn(req)
    res.status(200).json(successAction(updatingUser, 'user updated sucessfully'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
};



// Delete a user
exports.deleteUser = async (req, res) => {
  try {
    const deletingUser = await userServices.deleteUserfn(req)
    res.status(200).json(successAction(deletingUser, 'user deleted sucessfully'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}