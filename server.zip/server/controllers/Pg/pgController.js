const PG = require("../../models/pgDetails")
const mongoose = require("mongoose")
const { successAction, failAction } = require("../../utilities/response")
// const path = require("path")
const path = "http://localhost:4500"
const pgServices = require("../../services/pg/pgServices")




exports.CreatePg = async (req, res) => {
  try {
    const creatingPg = await pgServices.CreatePgService(req)
    res.status(200).json(successAction(creatingPg, 'pg created'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}

exports.getPg = async (req, res) => {
  try {
    const gettingPg = await pgServices.getPgServices(req)
    res.status(200).json(successAction(gettingPg, 'here is your  pg '))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}




exports.getAllPg = async (req, res) => {
  try {
    const gettingAllPg = await pgServices.getAllPgService(req)
    res.status(200).json(successAction(gettingAllPg, 'here is your all pg details '))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
};

exports.getAllPgByCity = async (req, res) => {
  try {
    const gettingAllPgCity = await pgServices.getAllPgByCityServices(req)
    res.status(200).json(successAction(gettingAllPgCity, 'here is your all pg details by city '))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
};

exports.getPgByFavourite = async (req, res) => {
  try {
    const gettingPgByFavourite = await pgServices.getPgByFavouriteService(req)
    res.status(200).json(successAction( gettingPgByFavourite, 'here is your all faviourite pg '))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
};

exports.updateFavPg = async (req, res) => {
  try {
    const updatingFavPg = await pgServices.getPgByFavouriteService(req)
    res.status(200).json(successAction( updatingFavPg, 'here is your updated faviourite pg '))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}



exports.updatePg = async (req, res) => {
  try {
    const updatingPgService = await pgServices.updatePgService(req)
    res.status(200).json(successAction( updatingPgService, 'here is your updated faviourite pg '))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}

exports.deletePg = async (req, res) => {
  try {
    const deletePgService = await pgServices.deletePgService(req)
    res.status(200).json(successAction( deletePgService, 'pg deleted successfully'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
}


exports.searchPg = async (req, res) => {
  try {
    const searchingPg = await pgServices.deletePgService(req)
    res.status(200).json(successAction( searchingPg, 'here is your result which you have searched'))
  } catch (error) {
    res.status(400).json(failAction(error.message, 400))
  }
};