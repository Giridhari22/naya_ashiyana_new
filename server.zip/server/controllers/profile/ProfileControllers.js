
const Profile = require("../../models/ProfileModel");
const { successAction, failAction } = require("../../utilities/response")
const ProfileServices = require("../../services/Profile/profileServices")

// exports.createProfile = async (req, res) => {
//     try {
//         // Validate request body
//         const {
//             ownerId,
//             f_name,
//             l_name,
//             email,
//             phone,
//             date_of_birth,
//             city,
//             state,
//             zip_code,
//             description,

//             company_name,
//             currency_name,
//             employment_type
//         } = req.body;
//         const image = req.file.filename;
//         // Check required fields
//         if (!ownerId ||!f_name || !l_name || !email || !phone || !date_of_birth || !city || !state || !zip_code || !description || !image || !company_name || !currency_name || !employment_type) {
//             return res.status(400).json({ error: "All fields are required." });
//         }

//         // Create a new profile
//         const newProfile = new Profile({
//             ownerId,
//             f_name,
//             l_name,
//             email,
//             phone,
//             date_of_birth,
//             city,
//             state,
//             zip_code,
//             description,
//             image: image,
//             company_name,
//             currency_name,
//             employment_type,

//         });

//         // Save the profile to the database
//         const savedProfile = await newProfile.save();

//         res.status(201).json(savedProfile);
//     } catch (error) {
//         console.error(error);
//         res.status(500).json({ error: "Internal Server Error" });
//     }
// }

exports.createProfile = async (req, res) => {
    try {
        const creatingProfile = await ProfileServices.createProfileService(req)
        res.status(200).json(successAction(creatingProfile, 'profile created'))
    } catch (error) {
        res.status(400).json(failAction(error.message, 400))
    }
}

exports.getProfile = async (req, res) => {
   
    try {
      const gettingProfile = await ProfileServices.getProfileServices(req)
      res.status(200).json(successAction(gettingProfile, 'here is your  profile '))
    } catch (error) {
      res.status(400).json(failAction(error.message, 400))
    }
  }


exports.deleteProfile = async (req, res) => {

    try {
        const deletingProfile = await ProfileServices.deleteProfileServices(req)
        res.status(200).json(successAction(deletingProfile, 'profile deleted successfully'))
    } catch (error) {
        res.status(400).json(failAction(error.message, 400))

    }
}