const User = require("../../models/userModels")
const bcrypt = require('bcrypt');
const message = require("../../utilities/messages")
const jwt = require("jsonwebtoken")
const mongoose = require("mongoose")
const nodemailer = require("nodemailer");
const { transporter, generateOTP } = require("../../utilities/customFunction")

exports.SignupUserfn = async (req, res) => {
    const { name, email, phone, password } = req.body

    // Validate the request body
    if (!name || !email || !phone || !password) {
        // return res.status(201).json({ msg: 'Missing required fields' });
        const error = new Error("Missing required fields");
        error.statusCode = 400;
        throw error;
    }
    const existingUser = await User.findOne({ email });
    const salt = await bcrypt.genSalt(10);
    if (existingUser) {

        const error = new Error("User already exists");
        error.statusCode = 400;
        throw error;
        // throw new Error('User already exists')
    }
    const user = new User({
        name,
        email,
        phone,
        password: await bcrypt.hash(password, salt),
        isActive: true,
    });
    await user.save();

    return user

}


// send otp
exports.sendOtpfn = async (req, res) => {
    const { email } = req.body;
    // Generate a random OTP
    const otp = generateOTP();
    const user = await User.findOneAndUpdate({ email }, { otp });
    if (user) {
        // Send the OTP to the user's email
        const mailOptions = {
            from: '"Giridhari jha 👻" <testingsdd123@gmail.com>',
            to: email,
            subject: "OTP for Login",
            text: `Your OTP for login is: ${otp}`,
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {

                console.log(error);

                const error = new Error("Failed to send OTP");
                error.statusCode = 400;
                throw error;
            } else {
                console.log("Email sent: " + info.response);
                return user
            }
        });
    } else {

        const error = new Error("User not found");
        error.statusCode = 400;
        throw error;
    }
}

// for login service
exports.Loginfn = async (req, res) => {
    const { email, otp } = req.body;
    // Check if the user with the given email exists
    const user = await User.findOne({ email });
    if (!user) {
        const error = new Error("User not found");
        error.statusCode = 400;
        throw error;
    }

    // Check if the OTP matches
    if (otp === user.otp) {
        user.isActive = true;
        user.save();
        let token = jwt.sign({ user: user, isUser: true }, "mynameisgiri");
        const results = { token, user }
        return results
    } else {
        const error = new Error("Invalid OTP");
        error.statusCode = 400;
        throw error;
    }
}


//   for resending otp
exports.resendOtpfn = async (req, res) => {
    const { email } = req.body;

    // Check if the user with the given email exists
    const user = await User.findOne({ email });
    if (!user) {
        const error = new Error('User not found');
        error.statusCode = 400;
        throw error;
    }

    // Generate a new OTP
    const newOtp = generateOTP();
    user.otp = newOtp;
    await user.save();

    // Resend the OTP to the user's email
    const mailOptions = {
        from: '"Giridhari jha 👻" <testingsdd123@gmail.com>',
        to: email,
        subject: 'Resent OTP for Login',
        text: `Your new OTP for login is: ${newOtp}`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log(error);
            const error = new Error('Failed to resend OTP');
            error.statusCode = 400;
            throw error;
        } else {
            console.log('Email sent: ' + info.response);
            return user
        }
    });
}


// get user 
exports.getUserfn = async (req, res) => {
    const users = await User.find();
    return users

}

// updating user service
exports.updateUserfn = async (req, res) => {
    
        const { name, email, phone, password, isActive } = req.body;
        const { id } = req.params.id;

        // Validate the request body
        if (!name || !email || !password || !phone) {

            const error = new Error('Missing required fields');
            error.statusCode = 400;
            throw error;
        }

        // Check if the user exists
        const user = await User.findById(id);
        if (!user) {
            const error = new Error('user not found');
            error.statusCode = 400;
            throw error;
        }

        // Update the user
        user.name = name;
        user.email = email;
        user.phone = phone;
        user.password = password;
        user.isActive = isActive;

        // Save the user
        await user.save();

        // Send a 200 OK response
        return user;
   
};


exports.deleteUserfn = async (req, res) => {
      const { id } = req.params;
      console.log(id)
      // Validate the request parameter
      if (!id) {
        const error = new Error('Missing required parameter');
        error.statusCode = 400;
        throw error;
      }
  
      // Check if the customer exists
      const user = await User.findByIdAndRemove(id);
      if (!user) {
        const error = new Error('user not found');
        error.statusCode = 400;
        throw error;
      }
  }