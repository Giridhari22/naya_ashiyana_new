const mongoose = require("mongoose");
const Owner = require("./ownersModel");

const profileSchema = new mongoose.Schema({
    ownerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: Owner
    },
    f_name: {
        type: String,
        minlength: 2,
        maxlength: 50,
    },
    l_name: {
        type: String,
        minlength: 2,
        maxlength: 50,
    },
    email: {
        type: String,
        unique: true,
    },
    phone: {
        type: Number,
    },
    date_of_birth: {
        type: Date,
    },
    city: {
        type: String,
    },
    state: {
        type: String,
    },
    zip_code: {
        type: String,
    },
    description: {
        type: String,
    },
    image: {
        type: String,
    },
    company_name: {
        type: String,
    },
    currency_name: {
        type: String,
    },
    employment_type: {
        type: String,
    },  
    isActive: {
        type: Boolean,
        default: true,
    },
}, { timestamps: true });

const Profile = mongoose.model('Profile', profileSchema);
module.exports = Profile;
