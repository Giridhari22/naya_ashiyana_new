const passport = require('passport');
const FacebookStrategy = require('passport-facebook').Strategy;
const User = require('./models/userModels');
const jwt = require("jsonwebtoken");
const Owner = require('./models/ownersModel');
const GoogleStrategy = require('passport-google-oauth2').Strategy;
// const GithubStrategy = require("passport-github2").Strategy;

// for google
passport.use(new GoogleStrategy({
  clientID: "320650663751-cotb0vah6olidasf8433jfse8aj3bkl3.apps.googleusercontent.com",
  clientSecret: "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",
  callbackURL: "http://localhost:4500/auth/google/callback",
  passReqToCallback: true
},
  async (request, accessToken, refreshToken, profile, done) => {
    console.log({ profile })

    const existingUser = await User.findOne({ googleId: profile.id });

    if (existingUser) {

      // User already exists, log in
      let token = jwt.sign({ user: existingUser, isUser: true }, "mynameisgiri");
      console.log({ token })
      // return done(null,existingUser);
      return done(null, existingUser, token);
    }

    // User doesn't exist, create a new user
    const newUser = new User({
      googleId: profile.id,
      name: profile.displayName,
      providerName: profile.provider,
      email: profile.email

    });

    await newUser.save();
    let token = jwt.sign({ user: newUser }, "mynameisgiri");

    // return done(null,newUser);
    return done(null, newUser, token);
    // done(null, newUser)
  }
));
// for owner


passport.use(
  new GoogleStrategy(
    {
      clientID: "320650663751-cotb0vah6olidasf8433jfse8aj3bkl3.apps.googleusercontent.com",
      clientSecret: "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",
      callbackURL: "http://localhost:4500/auth/google/callback",
      passReqToCallback: true,
    },
    async (request, accessToken, refreshToken, profile, done) => {
      console.log({ profile });

      const existingOwner = await Owner.findOne({ email: profile.email });

      console.log({ existingOwner })
      if (existingOwner) {
        // Owner already exists, log in
        let token = jwt.sign({ owner: existingOwner, isOwner: true }, "mynameisgiri");
        console.log({ token });
        return done(null, existingOwner, token);

      } else {
        // Continue with the owner creation process
        const newOwner = new Owner({
          googleId: profile.id,
          name: profile.displayName,
          providerName: profile.provider,
          email: profile.email,
        });

        await newOwner.save();
        // Generate and return the JWT token
        let token = jwt.sign({ owner: newOwner }, "mynameisgiri");
        return done(null, newOwner, token);
      }

    }
  )
);






//for github

// passport.use(
//   new GithubStrategy(
//     {
//       clientID: "bd27895abb194a5e6702",
//       clientSecret: "d752fd2429789311fd2a8222856600800264d285",
//       callbackURL: "http://127.0.0.1:8000/auth/github/callback"
//     },
//     function (accessToken, refreshToken, profile, done) {
//       done(null, profile);
//     }


//     // async(request, accessToken, refreshToken, profile, done) =>{
//     //   console.log({profile})

//     // const existingUser = await User.findOne({ githubId: profile.id });

//     // if (existingUser) {

//     //   // User already exists, log in
//     //   let token=jwt.sign({ user: existingUser, isUser: true }, "mynameisgiri");
//     //  console.log({token})
//     //   // return done(null,existingUser);
//     //   return done(null,  existingUser, token ); 
//     // }

//     // // User doesn't exist, create a new user
//     // const newUser = new User({
//     //   githubId: profile.id,
//     //   name: profile.displayName,
//     //   providerName:profile.provider,
//     //   email:profile.email

//     // });

//     // await newUser.save();
//     // let token=jwt.sign({ user: newUser}, "mynameisgiri");

//     // // return done(null,newUser);
//     // return done(null,  newUser, token );
//     // // done(null, newUser)
//     // }
//   )
// );


// for facebook

passport.use(
  new FacebookStrategy({
    clientID: "1266568103990946",
    clientSecret: "9c2020464347687da87b50b6a1916b73",
    callbackURL: 'http://localhost:4500/auth/facebook/callback',
    profileFields: ['id', 'displayName', 'photos', 'email']
  },
    async (accessToken, refreshToken, profile, done) => {
      console.log({profile})
      // Handle successful authentication here
      try {
        // Find or create user in your database based on profile information
        let user = await User.findOne({ facebookId: profile.id });

        if (!user) {
          // If user does not exist, create a new user
          user = new User({
            facebookId: profile.id,
            // email: profile.emails ? profile.emails[0].value : '', // Include email if available
            /* other user properties */
          });

          await user.save();
        }

        done(null, user); // Pass the user object to the callback
      } catch (error) {
        console.error(error);
        done(error); // Pass the error to the callback for failure handling
      }
    }
  ));

passport.serializeUser(function (user, done) {
  done(null, user);
})

passport.deserializeUser(function (user, done) {
  done(null, user);
})

module.exports = passport;